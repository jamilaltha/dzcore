def init(): print('D10Z READY')

def cli(): init()