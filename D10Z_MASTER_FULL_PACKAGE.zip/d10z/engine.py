def nodal_energy(x,f=1,v=1):
 import math
 return 0 if x<=0 else f*math.sqrt(v*math.log(x/1e-51))