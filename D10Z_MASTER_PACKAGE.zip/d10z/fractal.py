import math

def fractal_spiral(n=200,s=1):
    return [(math.log(i+1)*s*math.cos(i*.25), math.log(i+1)*s*math.sin(i*.25)) for i in range(n)]
