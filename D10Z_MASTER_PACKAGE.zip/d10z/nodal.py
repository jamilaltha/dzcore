from .engine import nodal_energy

def nodal_map(vals): return [nodal_energy(v) for v in vals]
